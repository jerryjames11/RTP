# Rise to Power v2 — Handoff to Claude Code

This is the engineering handoff. `GAMEFLOW.md` in this same folder is the design log (why decisions were made); this doc is the architecture map (how the code actually works) so you can extend it consistently instead of guessing.

> **Status update (post GAMEFLOW §10–18 build-out):** everything this handoff originally described as "not yet built" — Legislature, Country, World, Cabinet, Staff/Cabinet hiring, Rivals, the remaining random events, Campaign Strategy + regional polling + opposition research, Objectives/XP, and government budget/military — is now real and wired to the save, verified end-to-end in a browser. §8–11 below are kept as-written for historical accuracy (they describe the state *before* this build-out); the actual current wiring for everything they call "not yet built" is summarized in the new **§12 What got built** at the end of this doc. `build_bundle.py` was also rewritten (see §12) since the old one hard-coded exact-text patches that this build-out would have broken; the new version is pattern-based and should survive future edits more gracefully.

---

## 1. What exists right now

A browser political sim. Static HTML/CSS/JS, no backend, no build step, no framework. 17 pages, all hand-written, sharing a copy-pasted (not imported) set of conventions. Real systems: character creation, a real Jan-1-2026-forward Gregorian calendar with actual US election dates, a weekly stamina-budgeted action planner, fundraising with tier-scaled payouts, an individual donor relationship system, a reputation system, political capital, and a localStorage save. Legislature/Country/World **were** unbuilt stubs as of this paragraph's original writing — see the status note above and §12.

---

## 2. Two distribution formats — read this before touching anything

There are **two parallel outputs** built from the same 17 source files:

- **`rise-to-power-v2/` folder (+ its zip)** — the real site. Each page is its own file, linked by normal `<a href>` / `window.location.href`. Only works when downloaded and opened for real (or hosted). Cross-page `localStorage` may not share correctly on `file://` in some browsers (Chrome treats each `file://` URL as a distinct origin) — serve it over `http://localhost` via any static server if that happens.
- **`rise-to-power-v2-playable.html`** — a single self-contained file. Built by `build_bundle.py`, which:
  1. Copies all 17 source pages
  2. Patches every `window.location.href = '...'` navigation into a `navigate(target, params)` call that does `parent.postMessage({type:'rtp-nav', target, params})`
  3. Replaces per-page dynamic values (`office`, `name`, `age`, `econ`, `social`, `foreign`) that were read via `URLSearchParams` with literal placeholder tokens (`__OFFICE__`, `__NAME__`, etc.)
  4. Base64-encodes each patched page into a big `PAGES_B64` object
  5. Wraps it all in `shell_template.html`, which holds a single `<iframe id="stage">`, swaps its `srcdoc` on navigation, and does the `__PLACEHOLDER__` string substitution at render time

**Why two formats exist:** Claude.ai's artifact preview renders HTML in a sandboxed iframe. A page that does `<a href="other.html">` 404s in that preview because the iframe has no filesystem — it only has the one file's content. The bundle sidesteps this by never doing real navigation; everything is one file with an internal router. It also had to switch from a JS-computed `zoom` to a **fixed reference-width + `transform: scale()` on the iframe element**, because mobile browsers ignore `<meta name="viewport">` set *inside* an iframe — the scaling has to happen from the parent.

**If you add a new page:** it needs to work in both contexts. Pattern to copy from an existing page: read params via `new URLSearchParams(window.location.search)` for the standalone case; the bundler's `patch_*` functions in `build_bundle.py` regex-replace that whole block with the placeholder-literal version for the bundle. Look at `patch_office()` or `patch_calendar()` in `build_bundle.py` for the exact before/after pattern, and add a matching `patch_yourpage()` there, plus register the page in the `pages` dict near the bottom of that file and in `REF_WIDTHS` inside `shell_template.html` if it needs the fixed-width scaling treatment (dense multi-column pages do; simple mobile-first pages like `menu.html`/`character-creation.html`/`calendar.html` don't need it or already handle their own sizing).

### How to rebuild the bundle after making changes

```bash
python3 build_bundle.py          # reads ./*.html, writes pages_b64.py (needs bundle_src/ populated — see script header)
# then splice pages_b64 into shell_template.html's placeholder script tag and save as
# rise-to-power-v2-playable.html — see the two-step python snippet at the top of this repo's
# build history, or just ask Claude Code to redo the splice, it's ~10 lines.
```
`build_bundle.py` expects source files in a `bundle_src/` sibling folder (copy the 17 `.html` files there first). Read the top of the script; it's short and explicit.

---

## 3. File inventory

| File | Role |
|---|---|
| `menu.html` | Main menu. Begin/Continue Career read/write the save. Full background image, own `fit()` sizing logic (unrelated to the dense-page zoom system). |
| `character-creation.html` | 7-step wizard: country → state → city → gender → name → backstory+ideology → review. Writes the initial save. |
| `office.html` | The hub. By far the most logic-heavy file — see §8. |
| `calendar.html` | Week strip + month grid + stamina-budgeted action picker. Shares the real calendar engine and `ACTIONS` catalog with `office.html` (duplicated, not imported — see §5). |
| `campaign-city-council.html` … `campaign-president.html` (9 files) | One per office tier. Same layout, different data. Live-render Cash on Hand / Raised / Spent from `save.finances`. |
| `legislature.html`, `country.html`, `world.html` | Stubs. Full nav header, centered "coming soon" message. No content logic. |
| `settings.html` | Three tuning panels (political capital ledger, standing ledger, schedule rules). **Session-only — see §9, these are NOT wired to gameplay.** |
| `index.html` | Plain link list to every page, for browsing the multi-file folder. |
| `GAMEFLOW.md` | Design decisions log, chronological. |
| `BOX_MAP.md` | Box-by-box status index — every box, every page, live or static, with the exact function/id if live. |
| `mockups/*.html` | Six approved interactive HTML mockups (Legislature, Country, Staff, Cabinet, Rivals/Relationship Web, Campaign Strategy). Open these directly — they show the exact intended interaction, referenced throughout GAMEFLOW §10–18. |
| `build_bundle.py`, `shell_template.html` | The bundler. Included here so you can regenerate the playable file after changes. |

---

## 4. Shared conventions

**Palette** (CSS custom properties, redefined identically at the top of every page — not a shared stylesheet):
```
--bg:#0a0f1c  --bg-card:#111a2c  --bg-card-2:#0d1524
--border:rgba(255,255,255,.08)  --border-strong:rgba(255,255,255,.14)
--text:#f1f5f9  --text-dim:#8b96a8  --text-faint:#5b6576
--gold:#e0b563  --blue:#4c8dff  --green:#3ecf8e  --purple:#8b7cf6  --amber:#f0a94e  --red:#ef5164  --pink:#ec6f9c
```
Office and the 9 Campaign pages use a dense, small-type, data-table visual style (Football-Manager-inspired, per an explicit design request). Legislature/Country/World/Settings/Calendar are styled to match but keep their own simpler layouts.

**The duplicated-constants gotcha — read this twice.** There is no shared JS file. `ACTIONS`, `TIER_RATES`, `STAFF_COUNTS`, `NEWS_RULES`, the date-engine functions (`dateFromIndex`, `fmtShort`, etc.), and the `saveCareer`/`loadCareer` module are **copy-pasted verbatim into both `office.html` and `calendar.html`** (and a smaller subset into each campaign page). If you add a new action or change a payout formula, **you must edit it in both files identically**, or the picker in Calendar and the execution logic in Office will disagree. This was a deliberate tradeoff for zero-build-step simplicity; a real refactor to a shared module is reasonable future work but wasn't done here because the bundler's `srcdoc` iframes can't `import` across each other.

**Zoom-to-fit for dense pages.** `office.html` and the 9 campaign pages set `<meta name="viewport" content="width=1400">` — mobile browsers render them as a fixed 1400px canvas and auto-scale to fit the real screen, same trick as viewing a desktop site on a phone. This only works for the *standalone* files; the bundle achieves the same effect differently (§2).

**Cross-page context.** Office/Calendar/Campaign/Settings all thread `office`, `name`, `age`, `econ`, `social`, `foreign` through every internal link as query params, defaulted if absent. If you add a page that needs this context, follow the existing `extra` string-building pattern already in `office.html`'s script (search for `const extra =`).

---

## 5. Save schema (authoritative)

Single `localStorage` key: **`rtp_save_v1`**. Every page's `saveCareer(patch)` does a shallow `Object.assign(existing, patch)` — nested objects like `calendar` or `finances` must be read, mutated, and passed back whole, or you'll clobber sibling fields. `loadCareer()` returns `null` if nothing saved yet; every reader has a hardcoded default fallback (grep `get\(Finances\|Donors\|Reputation\|PoliticalCapital\)` in `office.html`).

```jsonc
{
  "character": {
    "name": "string", "age": "string", "country": "'US'",
    "st": "string (state name)", "city": "string",
    "gender": "'Male'|'Female'|'Non-binary'",
    "backstory": "string, matches a BACKSTORIES[].name",
    "econ": 0-100, "social": 0-100, "foreign": 0-100   // ideology sliders
  },
  "office": "office-tier slug, e.g. 'city-council'",   // see §7 for the 9 valid slugs
  "dayIndex": 0,            // integer days since Jan 1 2026 (epoch). ALWAYS Monday-aligned by convention — this doubles as "current week start"
  "calendar": {
    "chosen": { "<dayIndex>": ["Action label", "..."] }  // planned-not-yet-executed actions, keyed by absolute day index
  },
  "history": [              // unshift (newest first), capped to last 100
    { "weekStart": 0, "dayLabel": "Today · Jan 5", "label": "Media interview",
      "tag": "campaign|legislature|personal", "effect": "+2 media standing", "pc": 0 }
  ],
  "news": [                 // unshift, capped to last 20
    { "title": "string", "sub": "string", "time": "Just now|This week", "tag": "campaign" }
  ],
  "finances": { "cashOnHand": 85000, "totalRaised": 140000, "totalSpent": 55000 },
  "donors": [ { "id": "donor_starter|donor_<timestamp>_<rand>", "name": "string", "score": 0-100 } ],
  "reputation": { "authenticity": 100, "integrity": 70, "competence": 75, "popularity": 59 },
  "politicalCapital": 72    // uncapped, no floor either currently (can go negative — not yet decided if that should be blocked)
}
```

---

## 6. Real calendar & elections

Epoch: `new Date(2026,0,1)` = `dayIndex 0` (a real Thursday). All dates are computed via native `Date` math (`dateFromIndex`, `indexFromDate`, `getMonday`) — correct leap years and weekdays indefinitely, verified against real Election Days through 2200.

Election Day formula (`electionDayIndex(year)`): the actual US rule, Tuesday after the first Monday in November. Cadence table (`ELECTION_CADENCE` in `office.html`) maps each office slug to a start year + repeat interval (2/4/6 years). **Known simplification, stated explicitly in-code and in GAMEFLOW.md:** real state/local election calendars vary hugely (many states vote in odd years); this applies the federal formula uniformly. Fine for a game, worth knowing if realism scrutiny increases.

---

## 7. Office ladder (the 9 valid `office` slugs)

`city-council`, `mayor`, `state-house`, `state-senate`, `governor`, `us-house`, `us-senate`, `vp`, `president`. Term lengths and full ladder detail in `GAMEFLOW.md` §2. Every tier-scaled system (`TIER_RATES`, `STAFF_COUNTS`, `STAFF_CAPACITY`, `ELECTION_CADENCE`) is keyed by these exact strings — new offices need an entry in all four tables plus a `campaign-<slug>.html` file.

---

## 8. Systems that are fully wired (real save data, real math)

All of the below live primarily in `office.html`; `calendar.html` mirrors the parts it needs (the `ACTIONS` catalog, `TIER_RATES`, donor helpers) to compute the same numbers in the picker before execution.

| System | Data | Key functions (in `office.html`) | Trigger |
|---|---|---|---|
| **Weekly action planning** | `calendar.chosen` | `toggleAction`, `weekUsed` (in `calendar.html`) | Calendar picker, stamina-capped at 10/week |
| **Fundraising** | `finances` | `fundraisingAmount`, `applyFundraisingAction` | Any `isFundraising` action executing via `simEvent` or `advanceWeek` |
| **Individual donors** | `donors` | `weakestDonor`, `strongestDonor`, `applyFundraisingAction` (handles Prospect/Dinner/Ask branches) | Prospect new donor / Donor dinner / Major donor ask |
| **Donor exposure event** | `reputation.integrity`, `news` | inline in `simEvent`/`advanceWeek`, 28% roll on Major donor ask | First "random triggered event" built — see GAMEFLOW §9 for 4 more brainstormed but unbuilt |
| **Reputation** | `reputation` | `applyReputationDelta`, `REPUTATION_DELTAS` table, `ratingLabel`/`ratingColor` | Every executed action per its table entry |
| **Political capital** | `politicalCapital` | `pcDeltaFor`, `POLITICAL_CAPITAL_DELTAS` table | Every executed action; popup at `openPCModal` shows the transaction log by filtering `history` for `.pc !== 0` |
| **Weekly staff upkeep** | `finances` | inline in `advanceWeek`, `staffCount * TIER_RATES[slug].staffRate` | Advance Week only (not per-action) |
| **Staff roster (display only)** | `STAFF_COUNTS`/`STAFF_CAPACITY` (hardcoded, not saved) | `staffRoles`, `fillRoles`, `openStaffModal` | Click "View Staff" — generates a role breakdown (Campaign Manager, Field Organizers, etc.) proportional to capacity, filled top-down by current count. Works on Office **and** all 9 Campaign pages. Campaign Manager row drills into an Election Odds view (all 9 offices, age-based eligibility, `computeWinChance`). **No hiring mechanic — counts are static per tier, not player-changeable yet.** |
| **History log** | `history` | `renderHistory`, `showPanel('history')` | Sidebar nav item toggles the panel |
| **Election countdown** | derived, not stored | `nextElectionIndex`, `renderNextElection` | Computed fresh on every Office load from `dayIndex` + office slug |
| **Save / Continue / Restart** | whole save object | `saveCareer`/`loadCareer`/`clearCareer`, wired in `menu.html` + `office.html` sidebar buttons | Menu buttons, Office sidebar "Career" card |

---

## 9. Designed but NOT wired — a real trap to know about

`settings.html` has three editable ledgers (political capital rules, standing rules, schedule/upcoming-event lead times) that **look like live config but are pure session-local JS state** (`let rules = {...}`, never touches `localStorage`, never read by any other page). They were built as a **design/tuning UI during the brainstorming phase**, before the actual numbers got hardcoded into `office.html`/`calendar.html`'s `POLITICAL_CAPITAL_DELTAS`/`REPUTATION_DELTAS`/`TIER_RATES` tables directly. **The real numbers and the Settings-page numbers have already drifted apart** (Settings' political capital ledger still has the old "Win an election +20 / Pass a bill +10" legislative-flavored version from before Legislature existed; the real wired version is the smaller action-based table in §8).

Two honest paths forward: (a) make Settings actually read/write the live tables (turn it into a real config UI — bigger lift, touches every consumer), or (b) delete/relabel Settings as "reference only" and accept the numbers live in code. Flagging this explicitly so it doesn't get "fixed" by accident in a way that breaks the real math.

**Standing** (Party standing / Public opinion / Media standing) is now wired the same way — `getStanding`/`STANDING_DELTAS`/`applyStandingDelta`/`renderStanding` in `office.html`, action-delta pattern identical to Reputation. Public Opinion and Campaign's Polling Average are now the same shared value (`save.standing.opinion`), read directly on both pages. **Settings' standing ledger now has the same drift problem as its political capital ledger** — it still shows the older legislative-flavored rule set (vote with leadership, attend fundraiser, etc.) from before the real wiring used a smaller set of existing actions instead.

---

## 10. Not built at all — every one of these is now fully specced, most with an approved working mockup

Every item below was completely unscoped as of an earlier handoff revision. All of it has since been designed in a dedicated session with the person — **read `GAMEFLOW.md` §10–18 before building any of this**, not just this summary. Six items also have an **approved interactive HTML mockup** in `mockups/` — open these directly, they show the exact intended interaction, not just a description of it. Ordered by dependency (earlier items unblock later ones):

1. **Legislature: real bills** (GAMEFLOW §10, `mockups/legislature-mockup.html`) — full propose→vote→sign→veto pipeline at all three tiers, player's role depends on current office (legislator vs. executive), NPC bills auto-generate, veto override by supermajority, annual renewal through the same full pipeline, bills carry an explicit player-chosen ideological lean and their own funding request separate from the Budget's allocation, extreme-lean bills risk Public Opinion backlash, effects phase in over following weeks rather than landing instantly. The mockup shows the Legislative/Executive toggle and the Issue Categories box. This is the single biggest unblock — it enables:
2. **Policy asks from donors + PAC lobbying** (GAMEFLOW §11) — donor issue affinity tied to flavor (not random), PACs need ideology + standing + lobbying agreement all three, PAC money is passive/automatic once attracted.
3. **Staff hiring** (GAMEFLOW §12, `mockups/staff-candidate-pool-mockup.html`) — this is now the canonical hiring pattern, also used by Cabinet (item 6 below). Two sources: Candidate Pool (fresh named candidates, hiring removes them from the pool immediately) and Your Network (pulled from the Relationship Web — donors, allies, flipped-rivals — same perk as an equivalent pool tier but cheaper and less likely to leave). Filled roles still show their hiring options for replacement. Whoever's currently serving is a clickable profile with a Dismiss button. Hiring has a real Relationship Web effect: Network hires improve that contact's relationship, Pool hires get added to the web as a new Staff-type entry.
4. **Rivals + campaign announcement timing** (GAMEFLOW §13, `mockups/rivals-relationship-web-mockup.html`) — this one changes existing behavior: the Campaign gate needs to become locked until within 18 months of the real election date, anchored to the anniversary of taking office, not open on first click like it is now. Rivals seed on gate-confirm, scaling with office tier, with a `{name, threat, competence}` data model. The mockup shows rivals rendering in the Relationship Web (closer to center = more significant, same math as donors), a separate dashed "enemy zone" outside the normal web for foreign/severe threats (federal tiers only), and the full **Extend Olive Branch** action — a real Calendar action (3 stamina + 3 PC, real success-chance formula, real failure consequence) that the player triggers by clicking a specific rival's node, not an automatic event.
5. **The other 4 random events** (GAMEFLOW §14) — Donor Exposure is the working prototype. Endorsement, Viral moment, and Minor gaffe all have concrete trigger conditions and stat deltas specced and ready to build. Rival attack blocks on item 4.
6. **Country tab, World tab, and Cabinet hiring** (GAMEFLOW §15, `mockups/country-mockup.html`, `mockups/cabinet-hiring-mockup.html`) — Country is tier-relative (shows city/state/national data depending on current office, same box structure, mockup demonstrates all three via a Level toggle), non-executive offices get a spectator-only view. Cabinet hiring reuses the exact Staff pattern from item 3, single-slot named positions instead of Staff's generic multi-slot roles. The Budget drafting panel lives on Country (not Legislature) and only appears when Executive role + within the 100-day window — the mockup shows it as its own full-width row that pushes other content down, not squeezed into an existing row. World is federal-only (locked below us-house). Foreign policy bills reuse the Legislature pipeline from item 1.
7. **Campaign Strategy, Electoral Map, Opposition Research** (GAMEFLOW §16, `mockups/campaign-strategy-picker-mockup.html`) — issue-emphasis picker (pick 2 from the canonical 8-category list in §10, card-style single-select matching the character-creation backstory picker exactly). Each issue card shows three insights (Saliency, Standing, Donor/PAC Fit) gated by Campaign Manager tier — same precision system as Election Odds, reused rather than invented fresh: no manager hides insights, Junior gives vague categories, Senior gives ranges, Elite gives exact numbers plus a recommended-pick highlight. Electoral Map is a literal geographic map, not a data table — flagged because it's a meaningfully bigger frontend lift than everything else on this list. Opposition Research produces intel now with negative ads as a stated follow-up.
8. **Active Objectives and Experience/XP** (GAMEFLOW §17) — fixed milestone list and flavor-only respectively, both have concrete proposed numbers now, ready to implement directly. **Avatar creator** is explicitly deferred, not a gap. Two quick wires bundled into §17 too: Office's own Finances box should just mirror `save.finances` (same pattern as Polling Average), and Top Donors on Campaign pages should show real `save.donors` now rather than waiting on the PAC system.
9. **Government budget, military, and trade** (GAMEFLOW §18) — a third real pillar, separate from campaign finances entirely. Executive-only. Budget is a special annual bill with a 100-day drafting window before it's formally proposed (real dollar-amount sliders, not percentages, shown in the Country mockup), and it can pick up amendments during the legislative vote — this is real negotiation, not a yes/no. Military is funded from the Defense budget category with no separate upkeep, but needs a composition/development sub-system (branches not yet enumerated), and Governors get a scaled-down National Guard version of the same mechanic. Revenue comes from tax formulas plus domestic and international trade — ties into World's Trade section and the treaty system from item 6.

**What's genuinely still open**, not resolved by any mockup: exact vote-math thresholds per bill type, national-stat response curves, regional-polling aggregation formula, the tax revenue formula, the military branch/domain breakdown, and whether Mayor/Governor should get their own Department-head hiring (the Cabinet mockup deliberately left this as an open placeholder rather than guessing). These are calibration details Claude Code can reasonably default on, following the patterns already in the codebase (§8's fundraising formula, §9's reputation deltas) — but flagging them here so a default doesn't get mistaken for a locked decision.

---

## 11. Known limitations

- **localStorage doesn't work in Claude.ai's artifact preview sandbox** — confirmed, documented, not a bug. Works fine once downloaded/hosted.
- ~~No election resolution / win-loss gameplay loop.~~ **Fixed** — see §12. `resolveElectionIfDue` now rolls a real win/loss on Election Day using the existing win-chance formula; winning starts a term (officeholder, +20 PC, seeds Legislature colleagues), losing returns you to staffer, free to re-announce once the next 18-month window opens.
- **Political capital has no floor** — can go negative via the Major Donor Ask −1, uncapped in both directions. Still true, still an open question.
- **`file://` localStorage origin quirks** for the multi-file zip in some browsers — see §2.

---

## 12. What got built (GAMEFLOW §10–18 build-out)

Everything below is real, wired to the save, and was verified in a browser (a local `python3 -m http.server` + manual click-throughs and console-level state checks) rather than just written and assumed correct. Built in the dependency order GAMEFLOW itself lays out:

- **Career stage & election resolution** (new, wasn't in GAMEFLOW's own numbering — needed first because everything else depends on knowing candidate vs. officeholder): `save.careerStage`, `save.pendingElectionIndex`, `save.termStartIndex`, `save.priorOffices`. Resolved in `office.html` (and duplicated in each `campaign-*.html`, since a player might be mid-campaign when Election Day arrives while sitting on that page).
- **Legislature** (§10): `legislature.html` is a full propose→vote→pass/fail→sign/veto→law pipeline. `save.bills[]`, `save.congress` (drifts weekly), `save.colleagues[]` (Top Supporters/Opponents, moved by vote alignment), `save.lobbyingInfluence`. NPC bills auto-generate; NPC executives auto-sign/veto when the player isn't the executive at that tier; veto overrides on 67%+ support; signed effects phase in over 6 weeks; annual renewal. The canonical 8-category taxonomy (`BILL_CATEGORIES`) lives here and is reused by every downstream system.
- **Policy asks + PAC lobbying** (§11): donor `issue` tags, `save.policyAsks[]` (comply/decline UI on Office, resolves immediately), `save.pacs[]` + `save.lobbyingAgreements{}` (a Lobby toggle on Legislature's Lobbying Influence card) — attraction requires ideology decisiveness + standing/reputation threshold + an active agreement, all three.
- **Staff hiring** (§12): Candidate Pool (refreshes every 4 weeks) + Your Network, on Office **and** all 9 Campaign pages. `save.staff{role:[...]}`, `save.candidatePool{role:[...]}`, `save.staffContacts[]` (Staff-type purple Relationship Web nodes). Real gameplay hooks: Finance Director boosts fundraising, Communications/Digital staff boost standing/reputation gains, Field staff boost canvassing, Volunteer Coordinators raise the weekly stamina cap. Upkeep in `advanceWeek` sums real per-hire salaries; unfilled slots cost nothing.
- **Rivals + campaign timing** (§13): `save.rivals[]`/`save.enemies[]` seeded at gate-confirm, scaled by tier. The Campaign gate now locks each office until within 18 months of its real election (`withinAnnounceWindow`). Relationship Web renders rivals (red) and enemies (past a dashed ring). **Extend Olive Branch** is a real Calendar-pipeline action, queued by clicking a rival's node, resolved through `simEvent`/`advanceWeek`.
- **The remaining random events** (§14): Endorsement, Viral moment (after Constituent Office Hours), Minor gaffe, Rival attack — same probability-roll-into-news pattern as the original Donor Exposure prototype.
- **Country, World, Cabinet** (§15): `country.html`/`world.html` are fully live, not stubs. Country is tier-relative (city/state/national), executive-gated for the budget. A real **Budget** system: 100-day drafting window anchored to the term-start anniversary, real dollar sliders across the 8 categories, "Propose Budget Bill" goes through the actual Legislature pipeline, and signing it moves `save.country[level].approval`/`.debt` by its surplus/deficit — bills genuinely affect the nation now. Cabinet (president-only) reuses the Staff hiring pattern with 4 single-slot named positions. World is federal-only (locked below us-house), `save.world.countries[]` relations driven by passive drift + random world events + signed federal foreign-policy bills.
- **Campaign Strategy, regional polling, opposition research** (§16): a real primary/secondary issue picker on all 9 Campaign pages, insights gated by the real hired Campaign Manager's tier, donor/PAC fit computed from real data. Regional polling/Electoral Map/Key Races are **a stylized data-driven grid, not a literal geographic map** (a scoped-down decision, confirmed with the user — the underlying data model is real and upgradeable to real geographic SVG later). Opposition Research spends political capital to build real per-rival intel; negative ads remain a stated follow-up, not built.
- **Objectives, XP, quick wires** (§17): `save.objectives` (6 fixed milestones, computed from real save fields), `save.xp` (+10/action, +25/week), Office's Finances box now mirrors `save.finances`, Campaign's Top Donors renders real `save.donors` + PACs.
- **Government budget, military, trade** (§18): folded mostly into Country above ahead of schedule. Also added: military composition (`save.military.branches` — Army/Navy/Air Force/Cyber for federal, `save.nationalGuard` for state/governor), sub-allocated from the Defense/Foreign Policy budget category with sliders on Country, readiness drifting weekly toward a funding-implied target rather than snapping instantly. Revenue now has a real (if simple) formula tied to the governed level's own econGrowth/unemployment stats instead of a flat number.

**`build_bundle.py` was rewritten**, not just re-run: the old version hard-coded an exact multi-line "before" string per page to detect and rewrite navigation, which this build-out broke everywhere. The new version needs only two small, stable patterns per page (the one `URLSearchParams(window.location.search)` call, swapped for a placeholder-token shim; a handful of `window.location.href = ...` program­matic redirects, listed and patched explicitly) plus one universal injected `<script>` that intercepts clicks on any `<a href="X.html?...">` and reroutes them through `postMessage`, regardless of how that link's `href` was set. This is more robust to future edits, not just a one-time fix. `SRC` was also changed from a hard-coded `/home/claude/bundle_src` to a path relative to the script itself, since this environment isn't the same sandbox the original script was written for.

**Deliberate simplifications, stated so they don't get "fixed" by accident:**
- Regional polling numbers are derived live from `save.standing.opinion` plus a fixed per-region offset, not independently simulated per region.
- The Budget Bill's revenue estimate at the moment of signing still uses the flat per-tier baseline (`GOV_BUDGET_SCALE`), not the same econGrowth/unemployment-adjusted formula Country's own display uses — a minor inconsistency between the two, not a broken mechanic.
- Military readiness targets are a documented formula (funding share vs. baseline), not a deeper simulation.
- Opposition Research's "Negative Ads Ready" count is flavor only — the ads feature itself is a stated follow-up, per GAMEFLOW §16.

## 13. Real simulated elections for Congress composition (this pass)

Congress Breakdown's seat splits used to be either a static default or (briefly, in the prior pass) a weekly random nudge with no tie to the calendar at all — both were flagged as known gaps. This pass replaces that with real, staggered elections tied to the actual calendar:

- **Each tier is split into its real chamber components**, each carrying its own entry in the existing `ELECTION_CADENCE` table (no new cadence data invented): `local` → `city-council` (9 seats, all of it); `state` → `state-house` (65 seats, 2-yr cadence) + `state-senate` (35 seats, 4-yr cadence) — the 65/35 split is a documented stylized simplification, no real state has exactly 100 seats; `federal` → `us-house` (435, 2-yr) + `us-senate` (100, 6-yr) — this one matches the real Congress exactly. Splitting this way gets realistic staggering for free: components elect on different real November dates because their existing cadences already differ, not because of any new stagger logic.
- **`save.congressComponents`** (new) holds each component's own `{allies, opposed, ind, nextElection}`; `save.congress` is now a derived weighted rollup (`aggregateCongress`) kept for every existing consumer (`computeBillSupport`, Congress Breakdown) that already reads the tier-level shape — nothing downstream needed to change.
- **`resolveCongressElections`** fires only when a component's `nextElection` (a real dayIndex from `nextElectionIndex`) has actually passed, using a documented swing model — the player's own Public Opinion/Popularity as a national-mood proxy, plus randomness, capped to a ±15-point per-cycle swing. A `while` loop with a guard handles a save that skipped multiple cycles (e.g. reloading a stale save) so nothing is silently missed.
- **Every resolved election unshifts a real News entry** (`tag:'legislature'`), same pattern as every other News-producing system in the game — e.g. "U.S. Senate elections: your allies gain ground · 52% allied · 45% opposed · 3% independent".
- Wired into `office.html`'s `advanceWeek()` (replacing the old weekly drift block) and as a page-load check (`checkCongressElections()`) in both `office.html` and `legislature.html` — the latter needed its own copy of the whole election-date engine (`electionDayIndex`/`ELECTION_CADENCE`/`nextElectionIndex`), which it hadn't had at all before this pass, per the codebase's existing duplication convention.
- Congress Breakdown's caption changed from the old "doesn't shift on its own — known gap" to a real "Next Elections (staggered)" list showing each chamber's own upcoming date (with year, since the staggering is invisible without it — e.g. U.S. House Nov 2028 vs. U.S. Senate Nov 2032).
- **Verified end-to-end** via a jsdom smoke test (not just written and assumed correct): seeded a save as a sitting U.S. House officeholder, ran `office.html`'s real `advanceWeek()` 60 times (~1.2 years), confirmed 5 real election News entries fired on the correct real dates, confirmed `save.congress`/`save.congressComponents` updated correctly, then loaded `legislature.html` against that same save and confirmed the Congress Breakdown box rendered the correct seat math (535 total, correctly split) and the correct staggered next-election dates per chamber.
- `build_bundle.py` was re-run and the playable bundle re-spliced after these changes — both `office.html` and `legislature.html`'s edits are confirmed present in the rebuilt `rise-to-power-v2-playable.html` (checked directly against the bundle's own embedded page data, not assumed).

**Deliberate simplification carried forward:** the swing model is a national-mood proxy off the player's own stats, not an independent simulation of the "other side's" own campaign — reasonable for a single-player game where the player is the only fully-simulated actor, but worth knowing if a future pass wants opposing-party dynamics that don't route through the player's own numbers.

## 14. Opposition momentum: the swing model now has an independently-simulated "other side" (this pass)

The gap flagged at the end of §13 is fixed. Previously `simulateComponentElection` derived its entire swing from the player's own Public Opinion/Popularity plus randomness — there was no "other side," just a mood-proxy off the player. This pass adds a real second actor:

- **`save.oppositionMomentum`** (new) — `{ local, state, federal }`, one number per tier (not per component; the opposition's mood is tier-wide, matching how `DEFAULT_TIER_COMP` is already tier-scoped). Each starts at 0 (neutral) via `getOppositionMomentum(save)`'s fallback, same lazy-default pattern as `getCongressComponents`.
- **`stepOppositionMomentum(momentum)`** — the opposition's own weekly random walk, independent of anything the player does: small drift (±1.2) + mean-reversion (−4% toward 0, so it can't wander to an extreme and camp there) + a 5%-per-week chance of a larger ±6-point shock (an "opposition had a big week" event with no player-side trigger). Capped to ±30. Called once per real week in `office.html`'s `advanceWeek()`, right next to the existing lobbying-influence drift — same cadence, same "ticks every week whether or not an election happens" philosophy.
- **`simulateComponentElection(save, comp, slug, oppositionMomentum)`** — signature changed (now takes `slug` and the momentum object, previously just `save, comp`). The swing is now two independent terms plus noise: `playerInfluence` (the old player-stats term, scaled down ~40% from before — one campaign's coattails among many races, not the dominant factor now that there's a second real actor) minus `oppositionMomentum[tier] * 0.5` (the opposition's own trajectory, sized comparably so neither side mechanically dominates). Positive opposition momentum costs the player's allies ground.
- **News entries** now call out the opposition's momentum explicitly when it's the dominant driver of a result (`|oppMomentum| > 8`) — e.g. "U.S. House elections: your allies lose ground, as the opposition rides its own national momentum" — so the system is visible in play, not just internal math.
- **Legislature's Congress Breakdown box** gained a **National Environment** row (`renderOppositionMomentum`, new) showing the current tier's opposition momentum as "Favors the opposition" / "Favors your allies" / "Roughly balanced" with the raw number, right above the existing Next Elections list — the first place a player can see the opposing side's own trajectory without waiting for an election to reveal it indirectly.
- Duplicated identically into `office.html` and `legislature.html` per the codebase's existing no-shared-module convention (§4); `checkCongressElections()` in both files reads the current momentum but does not step it — only `advanceWeek`'s real weekly tick does, matching how lobbying influence's drift is also advanceWeek-only.
- **Verified** via a jsdom smoke test: seeded a US House officeholder save, ran `advanceWeek()` 60 times with the player's own stats held constant, and confirmed `oppositionMomentum` moved meaningfully off its 0 starting point purely from its own random walk — i.e. the opposition's trajectory is real and independent, not derived from the (unchanged) player numbers. Also confirmed `legislature.html`'s `renderCongressBreakdown()` renders the new National Environment row correctly.
- `build_bundle.py` was re-run and `rise-to-power-v2-playable.html` re-spliced; both files' changes confirmed present in the rebuilt bundle's embedded page data.

**What's still a simplification, flagged so it isn't "fixed" by accident:** momentum is one value per tier (local/state/federal), not per individual chamber component (city-council vs. mayor within "local," or state-house vs. state-senate within "state") or per real political party — it's a single national-mood-of-the-opposition number, not a multi-party system. Reasonable given the game already collapses politics into a two-side (allied/opposed) model everywhere else, but a future pass modeling three-plus parties or chamber-specific opposition dynamics would need to split this further.

