import os, base64, re

# Portable: bundle_src/ is a sibling of this script (copy the 17 source .html files there first).
SRC = '/home/claude/bundle_src_v6'

# ---------------------------------------------------------------------------
# Bundling strategy (rewritten to survive the GAMEFLOW §10-18 build-out without
# needing a hand-maintained exact-text patch per page):
#
# 1. Every page that reads `new URLSearchParams(window.location.search)` gets that single
#    expression replaced with a tiny object literal exposing the same `.get(key)` interface,
#    returning literal __OFFICE__/__NAME__/__AGE__/__ECON__/__SOCIAL__/__FOREIGN__ tokens.
#    shell_template.html already does a straight string substitution of those tokens across
#    the whole page body before setting srcdoc, so this "just works" no matter how a given
#    page's script is structured downstream -- only ONE exact string needs to match per file,
#    not an entire nav-wiring block.
# 2. A single injected <script> (NAV_HELPER) replaces real navigation for the whole bundle:
#    - `navigate(target, params)` posts a message to the parent shell (unchanged).
#    - A capture-phase document click listener intercepts any click on an `<a href="X.html?...">`
#      (however that href got set -- static markup or JS-assigned, doesn't matter) and calls
#      navigate() instead of letting the iframe try to load a real file (which 404s in srcdoc).
#    This replaces having to special-case every page's top-nav-wiring code individually.
# 3. The handful of places that navigate via `window.location.href = ...assignment` (not a link
#    click) still need a direct per-line patch, since there's no click to intercept. There are
#    exactly 13 of these across the whole app (verified by grep) -- listed explicitly below.
# ---------------------------------------------------------------------------

NAV_HELPER = '''<script>
function navigate(target, params){ parent.postMessage({type:"rtp-nav", target: target, params: params || {}}, "*"); }
document.addEventListener("click", function(e){
  var a = e.target && e.target.closest ? e.target.closest("a[href]") : null;
  if(!a) return;
  var href = a.getAttribute("href");
  if(!href || href === "#") return;
  var m = href.match(/^([a-zA-Z0-9_-]+)\\.html(?:\\?(.*))?$/);
  if(!m) return;
  e.preventDefault();
  var page = m[1];
  var qs = m[2] || "";
  var params = {};
  if(qs){
    qs.split("&").forEach(function(pair){
      if(!pair) return;
      var idx = pair.indexOf("=");
      var k = idx >= 0 ? pair.slice(0, idx) : pair;
      var v = idx >= 0 ? pair.slice(idx + 1) : "";
      try { params[decodeURIComponent(k)] = decodeURIComponent(v.replace(/\\+/g, " ")); }
      catch(err) { params[k] = v; }
    });
  }
  navigate(page, params);
}, true);
</script>
'''

QS_SHIM_OLD = "new URLSearchParams(window.location.search)"
QS_SHIM_NEW = ("{get:function(k){var m={office:'__OFFICE__',name:'__NAME__',age:'__AGE__',"
               "econ:'__ECON__',social:'__SOCIAL__',foreign:'__FOREIGN__'};"
               "return (k in m) ? m[k] : null;}}")

def inject_helper(html):
    return html.replace('<body>', '<body>\n' + NAV_HELPER, 1)

def patch_qs(html, fname):
    """Swap the one real URLSearchParams(window.location.search) construction for the token shim."""
    n = html.count(QS_SHIM_OLD)
    if n == 0:
        return html
    assert n == 1, f'{fname}: expected exactly 1 URLSearchParams(window.location.search), found {n}'
    return html.replace(QS_SHIM_OLD, QS_SHIM_NEW)

def patch_href_redirect(html, old, new, fname, required=False):
    n = html.count(old)
    if required:
        assert n >= 1, f'{fname}: expected redirect pattern not found: {old!r}'
    if n > 0:
        html = html.replace(old, new)
    return html

def patch_menu(html):
    old_begin = """function goBegin(){
  if(hasSave() && !confirm('Starting a new career will overwrite your saved progress. Continue?')) return;
  clearCareer();
  window.location.href = 'character-creation.html';
}"""
    new_begin = """function goBegin(){
  if(hasSave() && !confirm('Starting a new career will overwrite your saved progress. Continue?')) return;
  clearCareer();
  navigate('character-creation', {});
}"""
    assert old_begin in html, 'menu.html goBegin block not found'
    html = html.replace(old_begin, new_begin)

    old_continue = """function goContinue(){
  const save = loadCareer();
  if(!save){ ping('No saved career yet'); return; }
  const c = save.character || {};
  const q = new URLSearchParams({
    office: save.office || 'city-council', name: c.name || '', age: c.age || '',
    econ: c.econ != null ? c.econ : 50, social: c.social != null ? c.social : 50, foreign: c.foreign != null ? c.foreign : 50
  });
  window.location.href = 'office.html?' + q.toString();
}"""
    new_continue = """function goContinue(){
  const save = loadCareer();
  if(!save){ ping('No saved career yet'); return; }
  const c = save.character || {};
  navigate('office', {
    office: save.office || 'city-council', name: c.name || '', age: c.age || '',
    econ: c.econ != null ? c.econ : 50, social: c.social != null ? c.social : 50, foreign: c.foreign != null ? c.foreign : 50
  });
}"""
    assert old_continue in html, 'menu.html goContinue block not found'
    html = html.replace(old_continue, new_continue)

    html = html.replace(
        "onclick=\"ping('Settings')\"",
        "onclick=\"navigate('settings',{office:'city-council'})\""
    )
    return html

def patch_character_creation(html):
    old = """  const donors = starter ? [{id:'donor_starter', name:starter.name, score:starter.score, issue:starter.issue}] : [];
  saveCareer({
    character: {
      name: fullName, age: state.age, country: state.country, st: state.st, city: state.city,
      gender: state.gender, backstory: state.backstory, econ: state.econ, social: state.social, foreign: state.foreign,
      startEcon: state.econ, startSocial: state.social, startForeign: state.foreign
    },
    office: 'city-council',
    dayIndex: -(((new Date(2026,0,1)).getDay() + 6) % 7),
    calendar: { chosen: {} },
    donors: donors
  });
  const q = new URLSearchParams({
    office:'city-council', name:fullName, age:state.age,
    econ:state.econ, social:state.social, foreign:state.foreign
  });
  window.location.href = 'office.html?' + q.toString();
}"""
    new = """  const donors = starter ? [{id:'donor_starter', name:starter.name, score:starter.score, issue:starter.issue}] : [];
  saveCareer({
    character: {
      name: fullName, age: state.age, country: state.country, st: state.st, city: state.city,
      gender: state.gender, backstory: state.backstory, econ: state.econ, social: state.social, foreign: state.foreign,
      startEcon: state.econ, startSocial: state.social, startForeign: state.foreign
    },
    office: 'city-council',
    dayIndex: -(((new Date(2026,0,1)).getDay() + 6) % 7),
    calendar: { chosen: {} },
    donors: donors
  });
  navigate('office', {office:'city-council', name:fullName, age:state.age, econ:state.econ, social:state.social, foreign:state.foreign});
}"""
    assert old in html, 'character-creation.html startCareer block not found'
    html = html.replace(old, new)
    return html

def patch_settings(html):
    html = html.replace(
        'onclick="history.back()"',
        'onclick="navigate(\'office\',{office:\'__OFFICE__\'})"'
    )
    return html

CAMPAIGN_SLUGS = ['city-council','mayor','state-house','state-senate','governor','us-house','us-senate','vp','president']
fname_map = {
    'city-council':'campaign-city-council.html','mayor':'campaign-mayor.html',
    'state-house':'campaign-state-house.html','state-senate':'campaign-state-senate.html',
    'governor':'campaign-governor.html','us-house':'campaign-us-house.html',
    'us-senate':'campaign-us-senate.html','vp':'campaign-vp.html','president':'campaign-president.html'
}

def patch_campaign_extra(html, fname):
    # Self-referencing CAMPAIGN tab link used window.location.pathname, which is meaningless
    # inside a srcdoc iframe -- give it a real relative filename the click-interceptor can read.
    html = patch_href_redirect(
        html,
        "window.location.pathname.split('/').pop() + '?office=' + office",
        "'campaign-' + office + '.html?office=' + office",
        fname
    )
    # Gate confirm redirects via window.location.href, not a link click -- needs a direct patch.
    html = patch_href_redirect(
        html,
        "window.location.href = 'campaign-' + selectedGateOffice + '.html?office=' + selectedGateOffice;",
        "navigate('campaign-' + selectedGateOffice, {office: selectedGateOffice}); return;",
        fname,
        required=True
    )
    return html

def patch_office_extra(html, fname):
    html = patch_href_redirect(
        html,
        "window.location.href = 'character-creation.html';",
        "navigate('character-creation', {}); return;",
        fname,
        required=True
    )
    return html

def build_generic(fname):
    """Every page that doesn't need a bespoke redirect patch beyond the QS shim + nav helper."""
    html = load(fname)
    html = patch_qs(html, fname)
    html = inject_helper(html)
    return html

def load(name):
    with open(os.path.join(SRC, name), encoding='utf-8') as f:
        return f.read()

pages = {}

html = load('menu.html'); html = patch_menu(html); html = inject_helper(html)
pages['menu'] = html

html = load('character-creation.html'); html = patch_character_creation(html); html = inject_helper(html)
pages['character-creation'] = html

html = load('office.html'); html = patch_qs(html, 'office.html'); html = patch_office_extra(html, 'office.html'); html = inject_helper(html)
pages['office'] = html

html = load('calendar.html'); html = patch_qs(html, 'calendar.html'); html = inject_helper(html)
pages['calendar'] = html

html = load('settings.html'); html = patch_settings(html); html = inject_helper(html)
pages['settings'] = html

for pid in ['legislature', 'country', 'world']:
    html = load(pid + '.html'); html = patch_qs(html, pid + '.html'); html = inject_helper(html)
    pages[pid] = html

for slug, fname in fname_map.items():
    html = load(fname)
    html = patch_qs(html, fname)
    html = patch_campaign_extra(html, fname)
    html = inject_helper(html)
    pages['campaign-' + slug] = html

print('pages built:', sorted(pages.keys()))
needs_placeholder = {'office', 'settings', 'legislature', 'country', 'world', 'calendar'} | {'campaign-' + s for s in CAMPAIGN_SLUGS}
for k in needs_placeholder:
    assert '__OFFICE__' in pages[k], f'{k} missing __OFFICE__ placeholder'

b64 = {k: base64.b64encode(v.encode('utf-8')).decode('ascii') for k, v in pages.items()}

OUT = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(OUT, 'pages_b64.py'), 'w', encoding='utf-8') as f:
    f.write('B64 = ' + repr(b64))

print('total bytes (b64):', sum(len(x) for x in b64.values()))
