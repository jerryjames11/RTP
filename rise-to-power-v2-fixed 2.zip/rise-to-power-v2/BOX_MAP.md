# Rise to Power v2 — Box Map

Every box, on every page, and exactly where its data comes from. "Live" means it reads real `localStorage` save data and updates when that data changes. "Static" means the number is hardcoded HTML — same value forever, regardless of anything you do in the game.

Cross-reference: `HANDOFF.md` §8–10 covers this at the systems level; this doc is the box-level index. A few real gaps below aren't mentioned in HANDOFF and are worth folding in.

---

## Menu (`menu.html`)

| Box / control | Behavior |
|---|---|
| Begin Career | Clears save (confirms first if one exists), goes to Character Creation |
| Continue Career | Live — reads save, jumps to Office with saved character params. Dimmed if no save |
| Load Game | Static placeholder toast ("multiple save slots coming soon") |
| Settings (gear) | Goes to Settings |
| Crown / Academy / Stats / Achievements / Options | Static placeholder toasts, no pages built |

---

## Character Creation (`character-creation.html`)

| Box / step | Source |
|---|---|
| Country | Static list, only US enabled |
| State | Static 50-state list |
| City | Static per-state list (`CITY_DATA`), includes council seat counts |
| Gender | Static 3 options |
| Name fields | Free text, or Generate button pulls from `NAME_POOLS` by gender |
| Age | Free text, validated 18–99 |
| Backstory | Static `BACKSTORIES` array (8 options) — presets the ideology sliders and seeds a starter donor (`STARTER_DONORS`) |
| Ideology sliders | Adjustable after backstory picks a preset |
| Review | Just echoes the above |
| Start Career | Writes the entire initial save |

---

## Office (`office.html`)

**Profile card**
| Box | Source |
|---|---|
| Photo | Static placeholder — no avatar system exists |
| Name | Live — `save.character.name` |
| Party tag | Live — `save.party`, set via the Campaign gate. Shows "--" until set |
| Age | Live — `save.character.age` |
| Home State | Live — `save.character.st` |
| Running For | Live — `save.office` + `save.campaignGateSeen`. Shows "--" until a campaign is confirmed |

**Row 1**
| Box | Source |
|---|---|
| Standing table (Party standing / Public opinion / Media standing) | Live — `save.standing`, moved by `STANDING_DELTAS` on every executed action. Donor-exposure event now also dents Media standing (−4), on top of the Integrity hit |
| Political Capital (top-right of Standing box) | Live — `save.politicalCapital`, uncapped, click opens the transaction modal (chart + list, filtered from `history[].pc`) |
| Staff (current/capacity, progress bar) | Reads hardcoded `STAFF_COUNTS`/`STAFF_CAPACITY` tables (per office tier) — not save-backed, no hiring mechanic exists |
| View Staff → modal | Generates a role breakdown (`staffRoles`/`fillRoles`) from the same static capacity numbers |
| Campaign Manager row (inside that modal) | Live — clicking it swaps the modal to Election Odds: all 9 offices, real age-based eligibility (`save.character.age`), win% via `computeWinChance` (uses `save.reputation` + `save.politicalCapital`), precision keyed to `save.campaignManager` tier |

**Row 2**
| Box | Source |
|---|---|
| Upcoming Schedule | Live — `save.calendar.chosen`, day-grouped, next 7 days from `save.dayIndex` |
| Latest News | Live-if-present — renders `save.news` when non-empty; falls back to 4 static flavor items on a fresh save |
| Reputation (4 scores) | Live — `save.reputation`, moved by `REPUTATION_DELTAS` on every executed action |

**Row 3**
| Box | Source |
|---|---|
| Ideology (3 sliders) | Live — `save.character.econ/social/foreign`, set once at character creation. **Nothing in gameplay currently changes these after creation** |
| Relationship Web (radial diagram) | Live — `renderRelationshipWeb()` draws up to 6 nodes from `save.donors`, positioned by score (higher score sits closer to center), labeled with initials. All donors currently render as the amber "Donor" color since no Ally/Rival system exists yet |
| Finances | **Static** — this is a different box from Campaign's Finances; Office's copy was never wired even though Campaign's is |

**Row 4**
| Box | Source |
|---|---|
| Active Objectives | Static — no objective-tracking system exists |
| Experience/XP | Static — no XP system exists |

**Sidebar**
| Box | Source |
|---|---|
| Overview / History nav | History is live (`showPanel('history')` renders `save.history`, grouped by week) — everything else in that list (Attributes, Ideology, Reputation, Finances, Achievements) is decorative, doesn't switch panels |
| Next Decision | Live — earliest unresolved item in `save.calendar.chosen` for the current week; "Sim now" executes just that one action |
| Save career / Restart career | Both real — write/clear the save |
| Advance to Next Week (top bar) | Real — runs `advanceWeek()`: executes every chosen action for the week, applies fundraising/reputation/PC deltas, donor decay, staff upkeep, advances `dayIndex` by 7 |
| Next election (page subtitle) | Live — computed fresh every load from `nextElectionIndex` (real Election Day formula) against `save.dayIndex` and the current office |

---

## Calendar (`calendar.html`)

| Box | Source |
|---|---|
| Week strip | Live — `save.calendar.chosen` + `save.dayIndex` |
| Month grid | Same data, month view |
| Action picker | `ACTIONS` catalog (hardcoded, mirrors Office's copy). Donor Dinner/Major Donor Ask read `save.donors` to pick weakest/strongest and compute payout. Stamina capped at 10/week |
| Copy Last Week | Reads and rewrites `save.calendar.chosen` |

---

## Campaign (`campaign-*.html`, all 9 files — same boxes, tier-specific numbers)

| Box | Source |
|---|---|
| Choose Your Race gate (first visit only) | Real — writes `save.office`, `save.party`, `save.campaignManager`, `save.campaignGateSeen`. Win% odds use the same `computeWinChance` formula as Office's Election Odds view |
| Polling Average | Live — mirrors `save.standing.opinion` directly, same value shown on Office's Public Opinion row |
| Campaign Funds (Cash / Raised / Spent) | Live — `save.finances` |
| Staff | Same static `STAFF_COUNTS`/`STAFF_CAPACITY` numbers as Office (no hiring mechanic still) — but **View Staff now works**, opens the same roster modal + Election Odds drill-down Office has |
| Electoral Map | Static |
| Polling by Region | Static |
| Key Races table | Static |
| Campaign Strategy | Static |
| Top Donors | Static — hardcoded PAC-style names. Doesn't read `save.donors`, and no institutional-PAC system exists to generate these organically (scoped out during the donor-system build, see GAMEFLOW §8) |
| Recent Campaign Events | Live — filters `save.history` for `tag==='campaign'`, shows up to 4 most recent. Falls back to 3 static flavor items if none exist yet |
| Opposition Research | Static — no system built |

---

## Settings (`settings.html`)

Every ledger here is **session-only JS state** — none of it touches `localStorage`, none of it is read by any other page. See `HANDOFF.md` §9 for the full explanation of why (built during the design/brainstorming phase, before the real numbers got hardcoded directly into `office.html`/`calendar.html`).

| Panel | Behavior |
|---|---|
| Political capital rules | Editable list, resets on reload. Real PC math lives in `office.html`'s `POLITICAL_CAPITAL_DELTAS`, and the two have already drifted apart |
| Standing rules | Same — editable, not connected to anything. Standing itself **is** wired now (see Office §Row1), using a different, simpler action-based rule set than what's shown here — these two have drifted apart the same way Political Capital's did |
| Schedule/event lead times | Same |
| General toggles (sound, notifications, confirm-before-advance) | Cosmetic switches, no effect on anything |

---

## Legislature, Country, World (`legislature.html`, `country.html`, `world.html`)

> **Superseded — see the Summary below.** This section described the pre-build-out state (every box static). All three pages are now fully live: real Congress/bills, real tier-relative national stats + budget, real world relations. Left as-written above for historical contrast; don't take "every box is static" at face value anymore.

---

## Summary — what's actually real right now (post GAMEFLOW §10–18 build-out)

**Fully live, unchanged from before:** Political Capital, Fundraising, Individual Donors (scores + web diagram), Reputation, Standing (Party/Public Opinion/Media), Weekly action planning, History log, News (when populated), Election dates, Save/Continue/Restart, Campaign Funds, Recent Campaign Events, Home State.

**Newly live in this build-out — nothing left in this list is static:**
- **Office/Campaign career loop**: career stage (staffer/candidate/officeholder) and real election win/loss resolution — the "climb the ladder" loop actually functions now, not just a diagram.
- **Legislature**: real bills (propose/vote/sign/veto/law), Congress Breakdown (drifts), Top Supporters/Opponents, Lobbying Influence, NPC bill generation, veto overrides, annual renewal.
- **Staff hiring**: Candidate Pool + Your Network, on Office and all 9 Campaign pages, with real gameplay perks and real salary upkeep.
- **Rivals/Enemies**: seeded on campaign announce, rendered in the Relationship Web, flippable via a real Extend Olive Branch Calendar action.
- **The other 4 random events**: Endorsement, Viral moment, Minor gaffe, Rival attack.
- **Country**: tier-relative stats, real Active Policies, a real Budget system (100-day drafting window, real dollar sliders, Propose Budget Bill through the real Legislature pipeline, signed budgets move national approval/debt), Authority/Liberalization (derived), Military composition sliders.
- **World**: federal-only unlock gating (verified both locked/unlocked states), real country relations driven by standing drift + random events + signed foreign-policy bills, a Military Readiness stat.
- **Cabinet**: president-only, reuses the Staff hiring pattern, 4 single-slot named positions.
- **Campaign Strategy**: real primary/secondary issue picker, insights gated by the real hired Campaign Manager's tier, real donor/PAC fit.
- **Electoral Map / Polling by Region / Key Races**: a real, live, data-driven stylized grid (confirmed scope decision — not a literal geographic map; the data model is upgradeable to one later without changing anything else).
- **Top Donors**: real `save.donors` + `save.pacs`, not hardcoded names.
- **Opposition Research**: real per-rival intel accumulation (negative ads remain a stated follow-up, not built).
- **Active Objectives / Experience-XP**: 6 real fixed milestones computed from save data; XP accrues from actions and week-advances.

**Still deliberately static, unchanged:** everything in Settings (§9's known debt — the three ledgers still drift from the real wired tables, left broken on purpose, don't "fix" without checking in first).

**Genuinely open items, unresolved by any mockup, left as documented calibration defaults rather than blocking:** exact vote-math thresholds per bill type beyond simple-majority/supermajority-override, a deeper national-stat response simulation beyond the current approval/debt nudge, a literal regional-polling aggregation formula beyond the live opinion-plus-offset model, a revenue formula that's adjusted at Country's display layer but not yet threaded through to the moment a Budget Bill is actually signed, and a deeper military simulation beyond the current funding-share-implies-readiness-target model. See `HANDOFF.md` §12 for the full list of what was built and the file-by-file detail.
