# Button & Box Audit

Every clickable element across all 17 pages, checked against actual code — not assumed from patterns. "Wired" means real logic backs it. "Stale" means it looks clickable (often styled `cursor:pointer`) but has no handler and goes nowhere. "Placeholder" means it's clickable and gives honest feedback (a "coming soon" toast) rather than silently doing nothing — a real, intentional design choice, not a bug.

Campaign pages: audited `campaign-city-council.html` in full as the representative file, since feature-parity across all 9 tiers was independently verified in the last session (Polls box, Donors, Opposition Research, Events all confirmed present in all 9). The dead-icon and dead-sidebar findings below apply to all 9 equally, since they share the identical topnav/sidebar structure.

---

## Pattern that repeats across every page

**Three topnav icons are decorative on every single page that has them** (office, calendar, legislature, country, world, all 9 campaign pages): the notification bell *placeholder icon* (separate from office.html's real one — see below), an envelope/messages icon with a hardcoded "3" badge, and the settings gear. None have an `id`, none have a handler. This is one finding appearing ~12 times, not 12 separate bugs.

**Sidebar nav lists are decorative everywhere except Office's Overview/History.** Legislature (7 items), Country (5 items), Campaign pages (8 items) — every single sidebar entry has `cursor:pointer` styling but zero `onclick`. Office is the one exception: Overview and History actually switch panels; the other 5 items (Attributes, Ideology, Reputation, Finances, Achievements) are dead despite Ideology/Reputation/Finances all having real, working detail views *elsewhere* on the same page via their box's own link-row.

---

## office.html

**Wired:** Standing/Staff/Reputation/Ideology/Relationships/Finances modals (all via their link-row), Political Capital header click, notification bell (real dropdown, built this session), Save/Restart Career, Advance to Next Week, Sim Now (Next Decision card), sidebar Overview/History, top nav tabs, every Relationship Web node (donor/staff/rival/enemy) with type-appropriate info, Policy Ask comply/decline, Election Odds view, Staff role pools + hire + profile + dismiss.

**Stale:**
- "Plan your week in Calendar ›" — appears in the empty Next Decision state, styled like a nav link, doesn't navigate
- Envelope icon (✉️, badge "3") — topnav
- Settings gear (⚙️) — topnav, doesn't go to settings.html
- Sidebar: Attributes, Ideology, Reputation, Finances, Achievements (5 items)

## calendar.html

**Wired:** Day columns → action picker, action rows → toggle selection, month cells → jump to week, week/month view switching, Copy Last Week, tab navigation.

**Stale:** Same 3 topnav icons (bell/envelope/gear).

## legislature.html

**Wired:** Propose Bill flow (category pick, submit), Cast Vote, Sign Bill, Veto Bill, lobby agreement toggle, propose modal open/close.

**Stale:** Same 3 topnav icons. Entire sidebar (Overview, Congress, Bills, Committees, Votes, Laws, Lobbying — 7 items, including "Overview" itself despite being marked active).

## country.html

**Wired:** Cabinet modal (open/appoint/dismiss/position drill-in), Policy detail popup, Military allocation save (verified real, not a stub — persists to `save.military`), Budget draft propose.

**Stale:** Same 3 topnav icons. Sidebar (Overview, Economy, Approval, Regions, Policies — 5 items).

## world.html — the one page that's genuinely, entirely static

**Zero onclick handlers. Zero `.onclick` assignments. Zero wired buttons of any kind**, including "Advance to Next Week" itself, which works on every other page. This isn't a partial gap like the others — the whole page underneath its themed layout is inert. Sidebar (Overview, Countries, Treaties, Military — 4 items) is decorative like everywhere else, but here there's nothing *else* on the page that works either.

## menu.html

**Wired:** Begin Career, Continue Career.

**Placeholder (honest, not stale):** Settings gear, Premium, Load Game, Academy, Stats, Achievements, Options — all show a "— coming soon" toast. Intentional, not a bug.

## character-creation.html

**Wired:** fully — Generate Name, step navigation (Next/Back), all picker steps.

## settings.html

**Wired but intentionally disconnected from gameplay** — Add/Remove Row, Save Rules buttons for all three ledgers (political capital, standing, schedule) work and persist to `localStorage`, but per an earlier explicit decision in this project, none of it is read by the real game systems. Not a bug — documented, deliberate debt (see GAMEFLOW/HANDOFF).

## Campaign pages (all 9)

**Wired:** Polls (tabs + View Details modal), Finances (tabs), Staff (role pools + hire + profile), Campaign Strategy (Manage Strategy → picker), Top Donors (View all donors → per-donor Dinner/Ask), Recent Campaign Events (View all events), Opposition Research's *per-rival* Research buttons (queue → real stamina check → real intel/vulnerability system).

**Stale:**
- Same 3 topnav icons
- Entire sidebar (Overview, Polling, Funds, Staff, Strategy, Events, Voters, Ads, Opposition Research — 8 items)
- **"View Opposition Research"** — the card header's own expand link (`oppo-research-link`, has `cursor:pointer` styling and an id, genuinely no handler). This is separate from the per-rival Research buttons inside the card, which do work.
- **"View Map"** (Precinct Map box)
- **"View all precinct"** (Key Precincts box)

## The confirmed bigger gap: Precinct/State maps were only ever mockups

The clickable, targetable Precinct Map (grid, color-coded by lead, Hold Rally/Canvassing targeting) and the national-tier State Tile Map both exist only as standalone demonstration files from earlier in this project. Neither was ever wired into the real game — `campaign-city-council.html` and `campaign-president.html` both still show just a static box title with no `precinct-grid`/`state-grid` element anywhere. Hold Rally itself *is* real as a general Calendar action, but the location-targeting mechanic specifically was never built into the actual pages.
