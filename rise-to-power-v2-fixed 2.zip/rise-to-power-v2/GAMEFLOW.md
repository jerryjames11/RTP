# Rise to Power v2 — Game flow

Reference doc for design decisions made so far. Country pack: United States only.

> **Status: §10–18 are now built**, not just designed — see `HANDOFF.md` §12 for the file-by-file summary of what's real. This doc's content below is unchanged and remains the accurate *design* record (why each decision was made); it was written before implementation and isn't a status report, so don't read "not yet built" language later in this file as still true.

## 1. Career progression

```
Entry-level staffer      Office tab only
        v
Run for office            Campaign + Office tabs
        v  (lose -> retry)
Hold local office          Legislature tab unlocks
        v
Climb the ladder          State + national campaigns
        v
Win presidency             Country tab: full control
        v
World unlocked              Command every nation
```

## 2. US office ladder

| Tier | Office | Term |
|---|---|---|
| Local | City council | 2Y |
| Local | Mayor | 4Y |
| State | State house | 2Y |
| State | State senate | 4Y |
| State | Governor | 4Y |
| Federal | US house | 2Y |
| Federal | US senate | 6Y |
| Federal | Vice president | 4Y (rides the ticket) |
| Federal | President | 4Y |

## 3. Campaign page, by office tier

| | Electoral map | Funds | Staff | Polling regions | Key races table | Top donors | Strategy issues | Opposition research |
|---|---|---|---|---|---|---|---|---|
| Local (council/mayor) | Ward/district outline | $10K–200K | 5–20 | Neighborhoods | Key precincts | Local businesses | Zoning, potholes, schools | Local rumors, minimal |
| State (house/senate/governor) | Statewide county map | $1M–20M | 50–150 | Counties, media markets | Key counties | State PACs | Taxes, infrastructure | Moderate dossiers |
| US house | Single district map | $2M–5M | 20–50 | District precincts | Key precincts | Party committees, local PACs | District + national mix | Party-backed dossiers |
| US senate | Statewide county map | $20M–100M | 100–300 | Counties, media markets | Key counties | National Senate PACs | State + national issues | Full research operation |
| Vice president | Shares ticket's map | Shares ticket's fund pool | Shares president's staff | Swing states, home region | Same swing states as ticket | Same donors as ticket | Balance ticket, target swing states | Shared with ticket |
| President | National electoral college | $500M+ | 1,000+ | National + swing states | Key swing states | National Super PACs | Economy, security, foreign policy | Full national operation |

Each tier gets its own Campaign page build (`campaign-city-council.html` through `campaign-president.html`).

## 4. Character creation (Begin Career)

`character-creation.html`, 7-step flow:

1. **Country** — only United States enabled, others show "coming soon"
2. **State** — sets Home State field
3. **City** — sets home district (free text)
4. **Gender** — sets avatar, pronouns (avatar art itself is a later pass)
5. **Name** — first/last fields, generator considers country + state + gender
6. **Backstory & ideology** — pick 1 of 8 origin stories, which presets the Economic / Social / Foreign policy sliders; sliders stay adjustable
7. **Review** — confirm, then Start career → lands on `office.html`

Backstories: small business owner, community organizer, military veteran, union worker, farmer/rancher, tech entrepreneur, teacher, doctor.

## 5. Office page data sources

**Profile card**

| Field | Source |
|---|---|
| Photo | Avatar creator (later pass) |
| Name | Character creation — generator or manual entry |
| Party tag | Set when announcing a campaign for office |
| Status tag | Set when announcing a campaign for office, changes per office |
| Age, home state | Character creation |
| Ideology sliders | Set during character creation (backstory step), shifts with later decisions |

**Everything else on the page**

| Box | Source |
|---|---|
| Political capital | Campaign wins + bill success (see ledger below) |
| Experience | XP from actions across all tabs |
| Relationship web | NPCs met through Campaign (donors, staff) and Legislature (allies, rivals) |
| Reputation | Scored from player choices |
| Standing | Polling (Campaign), party votes (Legislature), media coverage |
| Finances | Personal job income pre-candidacy, then campaign funds after announcing |
| Latest news | Global event log |
| Active objectives | Dynamic goals generated per game stage |
| Upcoming schedule / next decision | Shared calendar pulling from Campaign, Legislature, Country |

## 6. Campaign page data sources

| Box | Source |
|---|---|
| Polling average | Actions, debates, news events |
| Campaign funds | Fundraising actions, weekly upkeep |
| Staff | Hiring actions, office-tier capacity |
| Electoral map | Aggregated regional polling |
| Polling by region | Targeted actions, local news |
| Key races table | Closest races in region data |
| Campaign strategy | Tied to ideology and actions taken |
| Top donors | Donor-tagged ties from the Office Relationship Web (already built) |
| Recent campaign events | Office History log, filtered to tag: campaign (already built) |
| Opposition research | Rival-tagged relationships + a research action system (not yet built) |

Top donors and Recent campaign events already have a real source (existing systems, just filtered). Everything else needs a new mechanic: fundraising/weekly upkeep, staff hiring, regional polling, and opposition research are the biggest gaps.

## 7. Political capital ledger

Editable at Settings → Political capital rules (`settings.html`). Triggered from different tabs, ruled centrally.

| Earn | Amount | Spend | Amount |
|---|---|---|---|
| Win an election | +20 | Push a bill to vote | −10 |
| Pass a bill | +10 | Call in a favor | −5 |
| Successful campaign event | +3 | Override party leadership | −15 |
| Positive news coverage | +3 | Emergency press conference | −8 |
| Ally endorsement | +5 | Request donor meeting | −3 |

## 8. Individual donor system

Data lives in the save as `donors: [{id, name, score}]`. Score is 0-100.

| Action | Cost | Rate | Effect |
|---|---|---|---|
| Prospect new donor | 2 | 0.3× tier rate | Adds a new donor, score 15–30, drawn from a name pool |
| Donor dinner | 2 | 1.5× tier rate | Picks your weakest donor, +10 score, modest payout |
| Major donor ask | 3 | 5.0× tier rate, scaled by score/100 | Picks your strongest donor, big payout, −15 score after |

Donor selection is automatic (weakest for dinner, strongest for ask) — no manual donor picker yet. Donors not engaged in a given week decay −1 score, floored at 10, applied during Advance Week. Character creation seeds one starting donor matched to backstory (e.g. Union worker → Local 402 Union, Tech entrepreneur → Bay Ventures Fund).

**Not yet built:** the Relationship Web diagram is still static — it doesn't render real donor data yet. Institutional PACs (Top Donors box) are a separate, not-yet-designed system: more passive, ideology/strategy-aligned rather than relationship-built.

**Future dependency — policy asks:** once Legislature has real bills, donors above a score threshold (~50) should be able to ask the player to vote yes/no or sponsor a bill, surfaced through Next Decision like any other sim-able action. Complying raises donor score (maybe a bonus contribution) but risks Public Opinion/Integrity if the bill is unpopular; declining drops donor score (repeated declines could flip a donor to Rival) but protects Integrity/Authenticity. Needs two things that don't exist yet: an issue tag on each donor to match against bill topics, and a controversy rating on each bill to compute the Public Opinion risk.

## 9. Reputation system

Data lives in the save as `reputation: {authenticity, integrity, competence, popularity}`, 0-100 each, starting at 100/70/75/59. No decay, unlike donors — only actions move it, applied on Sim now and Advance Week, same pipeline as fundraising.

| Action | Authenticity | Integrity | Competence | Popularity |
|---|---|---|---|---|
| Door-to-door canvassing | | | +1 | +1 |
| Media interview | +1 | | | +2 |
| Grassroots drive | +1 | | | +1 |
| Major donor ask | | −1 | | |
| Fundraiser event | | | | +2 |
| Constituent office hours | | +1 | +2 | |
| Staff meeting | | | +1 | |

Rating labels: Excellent (85+), Good (65+), Average (45+), Weak (25+), Poor (below).

**Donor exposure event** — the first triggered (non-player-chosen) event built. Every Major donor ask has a 28% chance of becoming public: if it hits, Integrity takes an extra −3 (on top of the base −1) and a news item runs ("Report ties large donation to [donor name]"). This is the prototype for the other triggered-event ideas (rival attack, endorsement, viral moment, minor gaffe) — same pattern, different trigger condition, not yet built.

## 10. Legislature system

Any office can propose bills. Three government tiers, each with a real propose→vote→sign→(veto) pipeline:

| Tier | Proposes & votes | Signs / vetoes |
|---|---|---|
| Local | City council | Mayor |
| State | State legislature | Governor |
| Federal | House / Senate | President (VP breaks Senate ties, also lobbies/whips votes without casting one) |

- **Player's role depends on current office.** Legislative tier (city-council, state-house, state-senate, us-house, us-senate) → propose + vote. Executive tier (mayor, governor, president) → sign or veto what the legislature sends up.
- **No cap on concurrent bills.** The executive calls bills to a vote.
- **NPC bills auto-generate on a regular cadence** so the page has organic activity even if the player proposes nothing.
- **Bills carry an issue category** (economy, healthcare, education, etc. — exact category list not yet enumerated). A category box on the Legislature page sorts categories by saliency to the constituents relevant to that office level.
- **Pass/fail**: real majority vote in the relevant body, using real rules for that body (exact vote math — simple majority vs. supermajority thresholds for specific bill types — still to be defined at implementation).
- **Veto can be overridden** by the legislature with a supermajority.
- **Passed bills require annual renewal** — goes through the same full propose→vote→sign pipeline as a brand-new bill, not a lighter check.
- **World-related bills** (treaties, military action, sanctions) go through this same pipeline at the federal level — foreign policy isn't a separate system.
- **Congress Breakdown (party composition) shifts over time** from simulated NPC elections for the other seats — not a fixed flavor number. Uses the same real election-cadence formula (`ELECTION_CADENCE`) already in the game, just applied to seats the player doesn't hold.
- **Top Supporters / Top Opponents are real individual colleagues**, parallel to donors — each with their own relationship score, built or eroded by voting alignment. Voting the way a colleague would push them toward Supporter; voting against them pushes toward Opponent. Needs its own data model (id, name, score) — not yet built.
- **Lobbying Influence affects bill pass odds.** A bill tagged to a sector where the player's Lobbying Influence is high (fed by which PACs are attracted, §11) gets better pass odds — this is the direct payoff for cultivating PAC relationships, not just a flavor meter.
- **Every bill has an ideological lean, explicitly chosen by whoever proposes it** — not auto-tied to its category. Same axis as the ideology sliders (econ/social/foreign depending on category). This is what actually drives the ideology-drift mechanic above; a bill's category alone doesn't determine direction.
- **Every bill also carries its own funding request**, chosen by the proposer, independent of how much the Annual Budget (§18) has allocated to that category. This is the bill's actual financial effect — not scaled by existing budget allocation.
- **Funding requests can be amended before the vote** — same negotiation mechanic as the Budget bill (§18): other legislators can propose changes to the ask to win their vote, real horse-trading rather than a fixed number.
- **Extreme-lean bills risk a Public Opinion backlash**, even while their targeted stat improves. A bold, strongly-leaning bill can move its target further but costs more Public Opinion risk than a moderate version of the same bill — a real tradeoff between boldness and safety, not a free lunch.
- **A signed bill's effects are delayed, not immediate** — they phase in gradually over the following weeks rather than landing all at once when signed. Exact phase-in curve not yet defined.
- **Canonical issue category list**, used everywhere a category is needed (bill tags, donor issue affinity §11, PAC lobbying sectors, Campaign Strategy picks §16): **Economy, Healthcare, Education, Public Safety, Environment, Immigration, Infrastructure, Defense/Foreign Policy.** One unified taxonomy — this replaces the original static mockup's separate 5-sector lobbying list (Business/Labor/Environmental/Healthcare/Defense), which would have been a second, overlapping category system.
- **Ideology can drift during gameplay** — voting on or proposing a bill nudges the econ/social/foreign sliders toward that bill's typical lean; complying with a donor's policy ask (§11) nudges ideology toward whatever position the donor wanted. Exact nudge magnitude not yet defined. This overturns the earlier assumption in §5 (Ideology box) that nothing in gameplay changes these after creation.

## 11. Policy asks (donors) and lobbying (PACs)

Unblocked by the Legislature system above. Two parallel mechanics:

**Individual donor policy asks** (dependency noted back in §8): once a donor's score crosses ~50, they can ask the player to vote yes/no or sponsor a bill matching their issue. Complying raises donor score (maybe a bonus contribution) but risks Public Opinion/Integrity if the bill is controversial; declining drops donor score (repeated declines could flip them to Rival) but protects Integrity/Authenticity.

**Donor issue affinity is tied to flavor**, not random — e.g. Bay Ventures Fund cares about economy/tech, Educators Alliance cares about education, Local 402 Union cares about labor issues. Applies to both `STARTER_DONORS` and anyone added via Prospect (needs a name→issue mapping table at implementation).

**PAC lobbying**: PACs are attracted by ideology alignment *and* Standing/Reputation crossing a threshold *and* the player agreeing to propose or lobby for/against bills the PAC cares about — all three matter, not just one. PAC contributions are **passive** — they accrue automatically every week once a PAC is attracted, no action required. Feeds the still-static "Top Donors" box on Campaign pages.

## 12. Staff hiring — and the shared hiring pattern (also used by Cabinet, §15)

- The View Staff panel gets **open slots per role**, for both campaign staff and in-office staff (the latter unlocks after winning — currently just an honest "unlocks after winning" label with no data behind it).
- **Two hiring sources, both leading to the same result:**
  - **Candidate Pool** — 3–4 fresh named candidates, tiered by quality (Junior/Experienced/Veteran), better tiers cost more weekly salary. **Hiring removes that candidate from the pool immediately**, even if the role still has open slots — the pool **refreshes periodically** with new faces over time.
  - **Your Network** — pulled directly from the player's existing Relationship Web (donors, allies, flipped-rivals with high enough competence, §13). Not every role has a network fit; the tab only appears when someone plausible exists. A network hire gives the **same role perk as an equivalent-tier pool candidate**, but costs **less salary** and is **less likely to leave** — that's the entire value proposition, not a different or better ability.
- **Filled roles still show their hiring options** — candidates (both sources) stay visible even when a role is full, so the player can browse a replacement. This applies per-slot on multi-slot roles (e.g. Field Organizers, 6 slots): each currently-serving person is listed individually alongside whatever capacity remains.
- **Whoever is currently serving a role is shown as a clickable entry**, opening a small profile (tier, salary, perk) with a **Dismiss** button that frees the slot. Previously filled roles just showed a bare count with no way to see who was actually in them.
- **Hiring has a real Relationship Web effect**, not just a stat change: hiring from Your Network improves that contact's relationship score (+15, proposed); hiring from the Candidate Pool adds the new hire to the Relationship Web as a **Staff**-type entry — the purple legend color that's existed since the web was first built but never had anything behind it.
- **Every staff role gives a real gameplay benefit** tied to its function (proposed mapping, not yet built):

| Role | Benefit |
|---|---|
| Campaign Manager | Sharpens Election Odds accuracy **and** Campaign Strategy insights (§16) — same tier system drives both, not just elections. Now hired the same way as every other role, replacing the old one-time gate cost with a recurring weekly salary |
| Finance Director | Boosts fundraising payouts |
| Communications Director / Digital & Media Team | Boosts Media standing and Popularity |
| Field Director / Field Organizers | Boosts canvassing effectiveness and Public Opinion |
| Volunteer Coordinators | Extra stamina or action capacity per week |

## 13. Rivals and campaign announcement timing

- **The Campaign gate is now locked** until the player is within 18 months of that office's next real election (using the existing `electionDayIndex` formula) — this changes existing behavior, since the gate currently opens on first Campaign tab click regardless of timing.
- **A Campaign Director notification** fires (News/notification) when the 18-month announcement window opens for the player's likely office.
- **Rivals get seeded when the gate is confirmed** (i.e. when the player announces). Rival count **scales with office tier** — more rivals in bigger races. Proposed counts (not yet locked, demonstrated in the Relationship Web mockup): city-council/mayor 1, state-house/state-senate/governor 2, us-house/us-senate/vp 3, president 4.
- Rivals need their own data model, parallel to `donors`: `{id, name, threat, competence}`. `threat` positions them in the Relationship Web exactly like donor `score` does (closer to center = more significant). `competence` is separate — high-competence rivals are eligible for the hiring pattern above (§12), same as allies and donors.
- **Enemies are a separate, more severe category from Rivals** — categorically outside the domestic political system, not part of the normal web math. Render outside a dashed boundary ring past the normal outer ring, connected by a faint dotted line rather than a solid one. Not eligible for hiring or the flip mechanic below. Gated to federal tiers only (us-house and up) — mirrors World being locked below that tier (§15), since a city council member has no realistic path to a foreign enemy. Proposed counts: 0 below us-house, 1 at us-house/us-senate/vp, 2 at president.
- **Rivals can flip to Ally, but only through direct player action — never automatically.** New Calendar action, **Extend Olive Branch**: costs 3 stamina + 3 Political Capital (spent regardless of outcome). Clicking a specific rival's node in the Relationship Web queues the action against that rival for the day — unlike donor actions, which auto-select weakest/strongest, this one lets the player choose the target directly. Resolves through the normal `simEvent`/`advanceWeek` pipeline, not instantly on click.
  - Success chance: 40% base, −0.4% per point the rival's threat sits above 50, +0.3% per point the player's Authenticity sits above 50, clamped 10–85%.
  - On success: rival becomes an Ally (moves into the normal web, no longer tagged Rival), +2 Authenticity, a News entry.
  - On failure: rival's threat +10 (capped 100), −2 Authenticity. A public overture that gets rebuffed is a real cost, not a free retry.
- This is also the prerequisite for the Rival Attack random event (§14).

## 14. The remaining random events

Donor Exposure (already built, §9) is the working prototype — a probability roll inside `simEvent`/`advanceWeek`, a stat delta, a News entry. Same pattern for the rest:

| Event | Trigger | Effect |
|---|---|---|
| Endorsement | Probabilistic while Public Opinion stays ≥70 | +3 Popularity, +2 Competence |
| Viral moment | Small chance after Constituent office hours executes | +2 Popularity, +1 Authenticity |
| Minor gaffe | Small weekly chance, rising as Integrity drops below 50 | −3 Authenticity, −2 Integrity |
| Rival attack | Needs the Rivals data model (§13) first | Not yet specced beyond that dependency |

## 15. Country and World tabs

- **Country is tier-relative**, not always-national. Same box structure (Approval, Key Stats, Top Issues, etc.), but scoped to whatever the player currently governs: city-level at city-council/mayor, state-level at state-house/state-senate/governor, national-level at us-house/us-senate/vp/president.
- **Non-executive offices get a mostly spectator Country view** — read-only context (approval, key stats visible) with no budget management, since Budget is executive-only (see §18). This is the same legislative-vs-executive split already governing the Legislature page (§10), applied to Country too.
- **The Annual Budget's drafting panel lives on Country, not Legislature** — Legislature's Active Bills still handles the actual Budget Bill vote once it's formally proposed (it's a bill like any other, §18), but the 100-day editable drafting experience belongs on Country, where the executive manages day-to-day governance.
- **World is federal-only** — locked/inaccessible below us-house tier.
- **Once president, Country's national stats actually respond** to bills passed and actions taken (GDP, unemployment, approval, etc.) rather than staying atmospheric — and per §10, that response is delayed/phased-in, not instant on signing. Exact response formulas (which bill categories move which stats, by how much) still need defining at implementation time.
- **Cabinet Approval (president-only) uses the exact same hiring pattern as Staff** (§12) — Candidate Pool + Your Network sourcing, always-visible candidates on filled positions, clickable currently-serving profile with Dismiss, relationship effects on hire. Only real difference: Cabinet positions are single-slot and individually named (Secretary of State, Treasury, Defense, Attorney General), not Staff's generic multi-slot roles.
- **World's Allies/Rivals (countries, not personal rivals) change via three layers**, all reusing systems already decided elsewhere:
  1. Primary driver — treaties and bills involving that country, via the Legislature pipeline (§10): sign a trade deal, relationship rises; sanctions, it falls.
  2. Passive drift — a slow ambient pull toward higher standing based on the player's Global Influence/Reputation; a strong, stable presidency naturally attracts warmer relations even without direct action.
  3. Random world events — occasional country-specific nudges (a trade dispute erupts, a nation requests closer ties), same random-event architecture as Endorsement/Gaffe/etc. (§14), scoped to World.

## 16. Campaign Strategy, Electoral Map, Opposition Research

- **Campaign Strategy**: the player picks two priority issues — primary and secondary — from the same bill-category list Legislature uses (§10). Card-style single-select for each slot, matching the backstory picker's interaction pattern from character creation, not a budget/points allocator. The two picks boost donor/PAC affinity matching either issue (§11) and give a polling bump in whichever regions rate that issue as most salient (the same saliency-sorted category box from §10).
  - **Each issue card shows three insights, gated by Campaign Manager tier** — the same tier system that drives Election Odds precision now drives this too (§12): no manager = insights hidden entirely; Junior = vague categories (High/Medium/Low, donor fit as a bare count); Senior = numeric ranges (±8 points, donor fit hints at type without naming names); Elite = exact numbers, real donor names, and a ★ RECOMMENDED tag on whichever issue scores best overall (saliency + standing + donor fit combined).
  - The three insights: **Issue Saliency** (how much constituents currently care, ties to §10's saliency box), **Your Current Standing** (player's existing reputation strength on that issue, tells you whether to double down or shore up a weakness), **Donor/PAC Fit** (which of the player's donors/PACs would respond best, ties to §11's issue affinity).
- **Electoral Map / Polling by Region / Key Races** region count scales with office tier: precincts at city-council/mayor, counties or districts at state tiers, all 50 states at president. **This is a literal geographic map, not a data table** — a real visual rendering per region type, which is a meaningfully bigger frontend lift than the other boxes on this page (needs actual map/boundary data per region granularity). How regional polling aggregates into the overall Polling Average is still to be defined.
- **Opposition Research** produces intel/info display now, with negative ads (a follow-up action spending that intel to hurt a rival's reputation/polling) planned as a later addition, not immediate. Depends on the Rivals data model (§13).

## 17. Settled without new systems

- **Active Objectives**: fixed milestones, the same list for every career. Proposed list: Win your first election, Raise $1M in campaign funds, Recruit 10 donors, Reach 65+ Public Opinion, Serve a full term without a scandal, Pass your first bill (once Legislature exists).
- **Experience/XP**: confirmed flavor-only — no mechanical effect, no unlock system. Proposed increment: +10 XP per executed action, +25 per week advanced.
- **Avatar creator**: explicitly deferred. Keep the placeholder box as-is.
- **Office's own Finances box** (separate from Campaign's, which is already live): just mirror `save.finances`, same pattern already used for Polling Average mirroring Public Opinion. Quick wire, no new system.
- **Top Donors on Campaign pages**: wire to real `save.donors` now rather than waiting on the PAC system — individual donors are already live data. PACs get added alongside once that system exists, not instead of this.
- **Settings' three ledgers stay deliberately broken** — explicitly decided, not an oversight. Don't "fix" the drift between Settings and the real wired tables (§7, and the standing note in §10) without checking back in first; leave it as known debt.

## 18. Government budget, military, and trade

A third real pillar, distinct from campaign finances (`save.finances`, the personal war chest) — this is taxpayer money, and only exists for executives (mayor, governor, president; Governor gets a smaller scope, see below).

**Budget as a special annual bill, with a drafting window:**
- Each executive gets a **100-day editable panel** after taking office (or at the start of each budget cycle) to draft their budget proposal — allocating revenue across the canonical 8 issue categories (§10).
- After the 100 days, the draft becomes a formal **Budget Bill** and goes through the normal propose→vote→sign pipeline (§10), same annual-renewal cadence as any other bill.
- **Amendments during the vote**: other legislators can propose amendments/riders to the budget bill to win their vote — the executive may need to concede categories or negotiate to build a passing coalition. This is real horse-trading, not a simple yes/no.

**Individual bills carry their own funding requests, separate from the Budget's category percentages** (§10). A regular bill's financial effect isn't scaled by how much the Annual Budget allocated to its category — it has an independent funding ask, chosen by the proposer and open to the same amendment negotiation as the Budget bill itself. How an individual bill's funding draws against the Budget's category envelope, or adds to deficit if it doesn't, is still an open question — worth resolving before implementation, since it affects whether National Debt (mentioned on the Country tab mockup) actually means anything.

**Revenue sources**: tax revenue (formula tied to Country tab's economic stats, exact formula TBD at implementation) plus trade revenue, both domestic and international. International trade revenue ties into World's Trade section and the treaty system (§15); domestic trade is presumably simpler/more abstracted, especially at lower tiers.

**Military** is funded from the Defense/Foreign Policy budget category — no separate weekly upkeep, it's covered under the budget like everything else. But it's not a single "strength" number: the player gets real control over **composition and development** — sub-allocating Defense spend across branches/domains (exact breakdown not yet enumerated — Army/Navy/Air Force/Cyber or similar), each accumulating its own readiness/strength over time from sustained investment. Feeds into World's Military section and Global Stability/conflict outcomes (§15).

**Governors get a scaled-down "National Guard" version** of the military system — same mechanic, smaller scope, state-level, funded from the state budget's Defense allocation.

## 19. Files built so far

| File | What it is |
|---|---|
| `menu.html` | Main menu. Begin/Continue Career read and write the save |
| `character-creation.html` | Begin Career flow: country, state, city, gender, name, backstory + ideology, review |
| `office.html` | Office tab overview. Live calendar sync, election dates, Save/Restart career, History panel |
| `calendar.html` | Week strip + month grid, stamina-budgeted action picker, copy-last-week |
| `campaign-city-council.html` | Campaign, local tier |
| `campaign-mayor.html` | Campaign, local tier |
| `campaign-state-house.html` | Campaign, state tier |
| `campaign-state-senate.html` | Campaign, state tier |
| `campaign-governor.html` | Campaign, state tier |
| `campaign-us-house.html` | Campaign, federal tier |
| `campaign-us-senate.html` | Campaign, federal tier |
| `campaign-vp.html` | Campaign, federal tier |
| `campaign-president.html` | Campaign, federal tier |
| `legislature.html` | Placeholder, tab-consistent header |
| `country.html` | Placeholder, tab-consistent header |
| `world.html` | Placeholder, tab-consistent header |
| `settings.html` | Political capital, standing, and schedule rule editors |
| `index.html` | Links every page above |
| `GAMEFLOW.md` | This doc |

Packaged two ways: `rise-to-power-v2.zip` (real multi-file site, needs to be downloaded and opened locally — Claude's preview can't follow links between files) and `rise-to-power-v2-playable.html` (single self-contained file, works inside Claude's preview too).

**Real systems now wired up:** localStorage save (character, ideology, calendar, history, news), real Gregorian calendar from Jan 1, 2026 through 2200, U.S. Election Day formula per office tier, week-advance execution engine that logs to History and generates News. Office and the 9 Campaign pages use a dense, data-table visual style (FM/spreadsheet-inspired) that scales to fit mobile; Legislature/Country/World/Settings/Calendar match the density but keep their existing layouts.

**Not yet built as of this doc's original writing:** Legislature, Country, and World tab content; fundraising/weekly upkeep; staff hiring; regional polling; opposition research; avatar creator. **All of the above except avatar creator (still explicitly deferred, per §17) are now built** — see `HANDOFF.md` §12.
